//
// main.c - demo for sw_clock v2.0 (slewed ADJ_OFFSET via PI)
//
#include <stdio.h>
#include <time.h>
#include <unistd.h>
#include "sw_clock.h"

static void print_ts(const char* tag, const struct timespec* t) {
    printf("%s: %lld.%09ld\n", tag, (long long)t->tv_sec, t->tv_nsec);
}

int main(void) {
    SwClock* c = swclock_create();
    if (!c) { perror("swclock_create"); return 1; }

    struct timespec rt0, raw0;
    swclock_gettime(c, CLOCK_REALTIME, &rt0);
    clock_gettime(CLOCK_MONOTONIC_RAW, &raw0);
    print_ts("RT start", &rt0);
    print_ts("RAW start", &raw0);

    // Request a +0.5s offset via slewing
    struct timex tx = {0};
    tx.modes  = ADJ_OFFSET | ADJ_MICRO;
    tx.offset = 500000; // +0.5s
    swclock_adjtime(c, &tx);
    printf("Requested +0.5 s slew (ADJ_OFFSET)\n");

    // Watch convergence for ~3 seconds
    for (int i=0; i<30; ++i) {
        struct timespec rt, raw;
        swclock_gettime(c, CLOCK_REALTIME, &rt);
        clock_gettime(CLOCK_MONOTONIC_RAW, &raw);

        long long d_rt_ns  = (long long)(rt.tv_sec - rt0.tv_sec) * 1000000000LL + (rt.tv_nsec - rt0.tv_nsec);
        long long d_raw_ns = (long long)(raw.tv_sec - raw0.tv_sec) * 1000000000LL + (raw.tv_nsec - raw0.tv_nsec);
        double phase_err_ms = (d_rt_ns - d_raw_ns) / 1e6; // approximate remaining phase vs. start

        printf("[t=%.2fs] RT-RAW phase (approx): %+8.3f ms\n", i*0.1, phase_err_ms);
        struct timespec wait = {.tv_sec=0,.tv_nsec=100000000L}; // 100 ms
        nanosleep(&wait, NULL);
    }

    swclock_destroy(c);
    return 0;
}
