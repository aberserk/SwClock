//
// sw_clock.h (v2.0 - slewed phase correction with PI + background poll thread)
//
#ifndef SW_CLOCK_H
#define SW_CLOCK_H

#ifdef __cplusplus
extern "C" {
#endif

#include <time.h>
#include <sys/time.h>

// -------- timex compatibility (for macOS) -------------------
#if __has_include(<sys/timex.h>)
  #include <sys/timex.h>
#else
  #ifndef __TIMEX_COMPAT__
  #define __TIMEX_COMPAT__

  struct timex {
      unsigned int modes;
      long offset;
      long freq;
      long maxerror;
      long esterror;
      int  status;
      long constant;
      long precision;
      long tolerance;
      struct timeval time;  // for ADJ_SETOFFSET
      long tick;
      long ppsfreq;
      long jitter;
      int  shift;
      long stabil;
      long jitcnt;
      long calcnt;
      long errcnt;
      long stbcnt;
      int  tai;
  };

  #ifndef ADJ_OFFSET
  #define ADJ_OFFSET      0x0001
  #endif
  #ifndef ADJ_FREQUENCY
  #define ADJ_FREQUENCY   0x0002
  #endif
  #ifndef ADJ_STATUS
  #define ADJ_STATUS      0x0010
  #endif
  #ifndef ADJ_TAI
  #define ADJ_TAI         0x0080
  #endif
  #ifndef ADJ_SETOFFSET
  #define ADJ_SETOFFSET   0x0100
  #endif
  #ifndef ADJ_MICRO
  #define ADJ_MICRO       0x1000
  #endif
  #ifndef ADJ_NANO
  #define ADJ_NANO        0x2000
  #endif

  #ifndef TIME_OK
  #define TIME_OK         0
  #endif
  #ifndef TIME_BAD
  #define TIME_BAD        5
  #endif

  // Status bits (stored, not interpreted here)
  #ifndef STA_PLL
  #define STA_PLL         0x0001
  #endif
  #ifndef STA_UNSYNC
  #define STA_UNSYNC      0x0040
  #endif

  #endif // __TIMEX_COMPAT__
#endif // <sys/timex.h>

#ifndef CLOCK_MONOTONIC_RAW
  #ifdef CLOCK_UPTIME_RAW
    #define CLOCK_MONOTONIC_RAW CLOCK_UPTIME_RAW
  #else
    #define CLOCK_MONOTONIC_RAW CLOCK_MONOTONIC
  #endif
#endif

// Opaque handle
typedef struct SwClock SwClock;

// Create / destroy. A background thread is spawned to call swclock_poll()
// at the configured interval; it is joined on destroy.
SwClock* swclock_create(void);
void     swclock_destroy(SwClock* c);

// Get / set time (software versions). RAW is passthrough to system.
int      swclock_gettime(SwClock* c, clockid_t clk_id, struct timespec *tp);
int      swclock_settime(SwClock* c, clockid_t clk_id, const struct timespec *tp);

// ntp_adjtime-like interface. Differences from v1.0:
// - ADJ_OFFSET & ADJ_SETOFFSET are SLEWED using an internal PI controller.
// - ADJ_FREQUENCY sets a base frequency bias (scaled-ppm, 2^-16 ppm).
// - ADJ_STATUS stored only.
int      swclock_adjtime(SwClock* c, struct timex *tptr);

// Explicit poll (normally called by the internal thread). Safe to call manually.
void     swclock_poll(SwClock* c);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // SW_CLOCK_H
